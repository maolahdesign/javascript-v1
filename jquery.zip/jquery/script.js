$("h1").css("color","red");
//jQuery(document).ready(function() {
//    alert("jQuery is loaded and ready!");
//});